
"""YOUR PoC PIPELINE — this is the file your group owns.

Lab contract = 5 automated steps, run by `python -m src.main ...`:
    01 load      input + provenance check (manifest.csv)
    02 process   your algorithm / model (the research part)
    03 rank      prioritise for a fixed review budget B
    04 review    human-in-the-loop: queue -> reviewer decisions -> overrides + audit log
    05 decide    GO / HOLD / REWORK (or track equivalent) with reason_code + owner, write outputs

Required output: out/<pred_file> with the columns listed for your track in
docs/tracks/TXX.md (also in src/metrics/tracks.py::TRACKS). Then evaluate with
    python -m src.evaluate --track tXX --pred out/<pred_file>

Rules: never read fixtures/*/gt/ here (the GT guard will stop you); seed everything via ctx.rng;
no network calls; fail loudly on missing models instead of downloading.
See src/examples/random_baseline.py for a minimal end-to-end wiring example.
"""
from __future__ import annotations

import pandas as pd

from .common.context import RunContext
from .common.decision import Decision, write_decision
from .common.manifest import verify_manifest
from .common.review import (
    load_review_decisions,
    make_review_queue,
    write_review_queue,
)
from .common.contact_sheet import render_contact_sheet
from .metrics.tracks import get_track

from .t02_scoring import (
    extract_dataset_features,
    score_blur_dark,
)


# ---------------------------------------------------------------- 01 load
def load(ctx: RunContext) -> dict:
    """Load T02 metadata and verify input provenance."""

    # 1. Verify data provenance using manifest.csv
    manifest_path = ctx.input_dir / "manifest.csv"

    problems = (
        verify_manifest(manifest_path)
        if manifest_path.exists()
        else [{"problem": "no_manifest"}]
    )

    if problems:
        ctx.audit.log(
            actor="pipeline",
            action="provenance_problems",
            item_id=str(manifest_path),
            after=problems[:20],
        )

        if ctx.config.get("strict_provenance", True):
            raise ValueError(
                f"provenance check failed ({len(problems)} problems), "
                f"first: {problems[:3]}"
            )

    # 2. Load manifest
    manifest = (
        pd.read_csv(manifest_path)
        if manifest_path.exists()
        else None
    )

    # 3. Load image metadata
    images_path = ctx.input_dir / "images.csv"

    if not images_path.exists():
        raise FileNotFoundError(
            f"Missing images.csv: {images_path}"
        )

    images = pd.read_csv(images_path)

    # 4. Validate required columns
    required_columns = [
        "image_id",
        "path",
        "camera_id",
        "light",
        "split",
    ]

    missing_columns = [
        col for col in required_columns
        if col not in images.columns
    ]

    if missing_columns:
        raise ValueError(
            f"images.csv is missing columns: {missing_columns}"
        )

    # 5. Validate image IDs
    if images["image_id"].isna().any():
        raise ValueError("images.csv contains missing image_id")

    if images["image_id"].duplicated().any():
        raise ValueError("images.csv contains duplicate image_id")

    # 6. Validate image paths
    missing_images = []

    for relative_path in images["path"]:
        image_path = ctx.input_dir / str(relative_path)

        if not image_path.is_file():
            missing_images.append(str(image_path))

    if missing_images:
        raise FileNotFoundError(
            f"Missing {len(missing_images)} image files. "
            f"First missing files: {missing_images[:5]}"
        )

    # 7. Return loaded data
    return {
        "manifest": manifest,
        "images": images,
    }


# ---------------------------------------------------------------- 02 process
def process(ctx: RunContext, data: dict) -> pd.DataFrame:
    """Extract and score Blur/Dark features for T02."""

    spec = get_track(ctx.track)

    if spec.track != "t02":
        raise NotImplementedError(
            f"Blur/Dark processing is only implemented for T02, "
            f"not {spec.track}"
        )

    if "images" not in data:
        raise ValueError(
            "process(): missing images metadata from load()"
        )

    # 1. Extract image features.
    features = extract_dataset_features(
        images=data["images"],
        input_dir=ctx.input_dir,
    )

    # 2. Calculate scores using DEV-only Blur references.
    scored = score_blur_dark(
        features=features,
        dev_split=ctx.param("dev_split", "dev"),
        min_group_size=int(ctx.param("min_group_size", 10)),
    )

    # 3. Preserve original relative image paths for human review.
    scored = scored.merge(
        data["images"][["image_id", "path"]],
        on="image_id",
        how="left",
        validate="one_to_one",
    )

    if scored["path"].isna().any():
        raise ValueError(
            "process(): missing image paths after metadata merge"
        )

    # 4. Combine Blur and Dark suspicion scores.
    scored["score"] = scored[
        ["blur_score", "dark_score"]
    ].max(axis=1)

    # 5. Validate output.
    required_columns = {"image_id", "score"}
    missing = required_columns - set(scored.columns)

    if missing:
        raise ValueError(
            f"process(): missing output columns: {sorted(missing)}"
        )

    if scored["image_id"].duplicated().any():
        raise ValueError(
            "process(): duplicate image_id in output"
        )

    if not scored["score"].map(
        lambda value: pd.notna(value) and 0 <= value <= 1
    ).all():
        raise ValueError(
            "process(): invalid score values"
        )

    ctx.stats["n_processed"] = len(scored)
    ctx.stats["scoring_method"] = "max_blur_dark_v1"

    return scored


# ---------------------------------------------------------------- 03 rank
def rank(ctx: RunContext, scored: pd.DataFrame) -> pd.DataFrame:
    """Rank suspicious T02 images and create a human-review contact sheet."""

    budget = int(ctx.param("budget", 20))

    if budget < 1:
        raise ValueError("rank(): budget must be >= 1")

    required_columns = {
        "image_id",
        "score",
        "blur_score",
        "dark_score",
        "camera_id",
        "light",
        "path",
    }

    missing = required_columns - set(scored.columns)

    if missing:
        raise ValueError(
            f"rank(): missing required columns: {sorted(missing)}"
        )

    # Work on a copy; do not modify the original scored DataFrame.
    ranked_input = scored.copy()

    # 1. Identify the dominant suspicion feature.
    ranked_input["reason"] = "blur_dark"

    ranked_input.loc[
        ranked_input["blur_score"] > ranked_input["dark_score"],
        "reason",
    ] = "blur"

    ranked_input.loc[
        ranked_input["dark_score"] > ranked_input["blur_score"],
        "reason",
    ] = "dark"

    # 2. Human review is required.
    # REVIEW is a suggestion, not an automatic defect decision.
    ranked_input["suggested_action"] = "REVIEW"

    # 3. Add camera and lighting context.
    ranked_input["slice"] = (
        ranked_input["camera_id"].astype(str)
        + "/"
        + ranked_input["light"].astype(str)
    )

    # 4. Preserve the relative image path.
    ranked_input["evidence_path"] = (
        ranked_input["path"].astype(str)
    )

    # 5. Create the top-B review queue.
    q = make_review_queue(
        ranked_input,
        id_col="image_id",
        score_col="score",
        budget=budget,
        reason_col="reason",
        action_col="suggested_action",
        slice_col="slice",
        evidence_col="evidence_path",
    )

    # 6. Save structured review queue.
    queue_path = ctx.out("review_queue.csv")
    write_review_queue(q, queue_path)

    # 7. Generate offline HTML contact sheet.
    # Thumbnails are embedded, so the HTML is portable.
    contact_sheet_path = ctx.out("contact_sheet.html")

    render_contact_sheet(
        queue=q,
        out_html=contact_sheet_path,
        image_col="evidence_path",
        image_root=ctx.input_dir,
        title="T02 Raw QC - Human Review",
        embed=True,
    )

    # 8. Record pipeline statistics.
    ctx.stats["n_ranked"] = len(q)
    ctx.stats["review_budget"] = budget
    ctx.stats["contact_sheet"] = str(contact_sheet_path)

    return q


# ---------------------------------------------------------------- 04 review
def review(
    ctx: RunContext,
    scored: pd.DataFrame,
    queue: pd.DataFrame,
) -> pd.DataFrame:
    """Load reviewer decisions if an exported review CSV exists.

    Reviewer overrides are not applied yet. The decision semantics and
    audit behavior must be implemented before accepting overrides.
    """

    reviewed_path = (
        ctx.output_dir / "review_queue_reviewed.csv"
    )

    if reviewed_path.exists():
        reviewed = load_review_decisions(reviewed_path)
        ctx.stats["n_reviewed"] = len(reviewed)

        # TODO:
        # Define T02-specific decision semantics.
        # Apply valid overrides and log every change to ctx.audit.

    return scored


# ---------------------------------------------------------------- 05 decide
def decide(
    ctx: RunContext,
    final: pd.DataFrame,
) -> Decision:
    """Placeholder decision policy; not ready for production."""

    return Decision(
        status="HOLD",
        reason_code="POLICY_NOT_IMPLEMENTED",
        reason="Decision policy not implemented yet",
        owner=ctx.config.get("owner", "TODO-owner"),
        scope=ctx.track,
    )


# ---------------------------------------------------------------- run
def run(ctx: RunContext) -> None:
    spec = get_track(ctx.track)

    data = load(ctx)

    scored = process(ctx, data)
    ctx.stats["n_items"] = len(scored)

    queue = rank(ctx, scored)

    final = review(ctx, scored, queue)

    # Keep the official prediction columns first.
    output_columns = (
        spec.pred_columns
        + [
            column
            for column in final.columns
            if column not in spec.pred_columns
        ]
    )

    final[output_columns].to_csv(
        ctx.out(spec.pred_file),
        index=False,
    )

    write_decision(
        decide(ctx, final),
        ctx.out("decision.json"),
        ctx.out("decision_log.csv"),
    )
